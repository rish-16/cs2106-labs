
// Maximum number of elements in a queue
//
#define MAX_Q_SIZE	10

// declare prototypes below

